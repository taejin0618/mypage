lang = 'python'
lang[0] = 'P'
print(lang)
