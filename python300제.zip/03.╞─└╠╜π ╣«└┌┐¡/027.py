url = "http://sharebook.kr"
url_split = url.split('.')
print(url_split[-1])
# 문자열로 표현된 url에서 `.`을 기준으로 분리합니다. 분리된 url 중 마지막을 인덱싱하면 도메인만 출력할 수 있습니다.
