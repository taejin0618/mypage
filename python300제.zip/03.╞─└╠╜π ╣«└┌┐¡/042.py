ticker = "BTC_KRW"
ticker = ticker.lower()
print(ticker1)