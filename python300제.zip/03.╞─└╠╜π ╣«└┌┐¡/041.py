ticker = "btc_krw"
ticker= ticker.upper()
print(ticker)