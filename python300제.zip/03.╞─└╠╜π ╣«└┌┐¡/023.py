string = "홀짝홀짝홀짝"
print(string[::2]) # `시작인덱스:끝인덱스:오프셋`을
