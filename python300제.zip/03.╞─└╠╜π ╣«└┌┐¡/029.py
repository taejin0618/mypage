string = 'abcdfe2a354a32a'
string = string.replace('a', 'A')
print(string)