name1 = "김민수"
age1= 10
job = "work"

name2 = "이철희"
age2 = 13

name3= "김태진"
age3 = 30
print("이름: %s 나이: %d 직업: %s" % (name1, age1, job))
print("이름: %s 나이: %d" % (name2, age2))
print("이름: %s 나이: %d" % (name3, age3))

# 포맷팅
#문자열 %s
#정수 %d
