name1 = "김민수"
age1= 10
job = "work"

name2 = "이철희"
age2 = 13

name3= "김태진"
age3 = 30
print("이름: %s 나이: %d 직업: %s" % (name1, age1, job))
print(f"이름: {name3} 나이: {age1}") #  f-string 사용해서 변경
print("이름: {} 나이: {}".format(name2, age2)) # format 매서드를 사용해서 변경

#    f-string은 문자열 앞에 f가 붙은 형태입니다. f-string을 사용하면 `{변수}`와 같은 형태로 문자열 사이에 타입과 상관없이 값을 출력할 수 있습니다.
# 포맷팅
#문자열 %s
#정수 %d
