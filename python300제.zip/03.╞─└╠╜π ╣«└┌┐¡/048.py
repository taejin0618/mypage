ticker = "btc_krw"
ticker.split("_")
print(ticker)
