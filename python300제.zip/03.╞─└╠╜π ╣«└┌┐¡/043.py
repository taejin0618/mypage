a = "hello"
a = a.capitalize()
