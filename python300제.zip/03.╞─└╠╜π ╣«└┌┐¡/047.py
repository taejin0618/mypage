a = "hello world"
a.split()
print(a)

#   문자열의 split() 메서드를 사용하면 문자열에서 공백을 기준으로 분리해줍니다.