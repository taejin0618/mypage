file_name = "보고서.xlsx"
file_name.endswith("xlsx")

print(file_name)
