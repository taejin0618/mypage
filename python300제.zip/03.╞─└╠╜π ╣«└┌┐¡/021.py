letters = 'python'
print(letters[0], letters[2])
