string = "python"
print(string[::-1]) #문자열 뒤집어서 출력
