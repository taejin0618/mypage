name1 = "김민수"
age1= 10
job = "work"

name2 = "이철희"
age2 = 13

name3= "김태진"
age3 = 30
print("이름: %s 나이: %d 직업: %s" % (name1, age1, job))
print("이름: {} 나이: {}".format(name1, age1))
print("이름: {} 나이: {}".format(name2, age2)) # format 매서드를 사용해서 변경

# 문자열의 포맷 메서드는 타입과 상관없이 값이 출력될 위치에 `{ }`를 적어주면 됩니다.

# 포맷팅
#문자열 %s
#정수 %d
