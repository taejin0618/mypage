print("naver/kakao/sk/samsung")
