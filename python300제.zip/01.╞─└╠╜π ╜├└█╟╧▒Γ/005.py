print("안녕하세요.\n만나서\t\t반갑습니다.")
#\n 줄바꿈
#\t tab
