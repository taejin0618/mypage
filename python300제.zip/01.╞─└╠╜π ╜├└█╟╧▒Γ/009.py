print("first", end="")
print("seconde")