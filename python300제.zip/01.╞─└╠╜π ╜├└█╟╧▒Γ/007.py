print("naver", "kakao", "samsung", sep=";")
