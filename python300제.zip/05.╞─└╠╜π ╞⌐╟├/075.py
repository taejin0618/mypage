t = 1, 2, 3, 4
print(t)

a = 1, 2
print(a)
