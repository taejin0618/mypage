temp = ('apple', 'banana', 'cake')
a, b, c = temp
print(a, b, c)