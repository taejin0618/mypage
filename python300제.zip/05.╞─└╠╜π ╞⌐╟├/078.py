interest = ["삼성전자", "LG전자", "SK"]
a = tuple(interest)

print(type(a))
print(type(interest))

