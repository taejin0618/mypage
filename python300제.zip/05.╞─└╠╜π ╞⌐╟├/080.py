data = tuple(range(2, 100, 2)) # 튜플 짝수 추출
print(data)