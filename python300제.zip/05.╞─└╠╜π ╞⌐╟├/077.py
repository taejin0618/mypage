interest = ('삼성전자', 'LG전자', 'SK Hynix')
data = list(interest)
print(interest)