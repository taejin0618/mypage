my_variable = ()

print(type(my_variable))
