my_tuple = (1)
print(type(my_tuple))

my_tuple = (1,)