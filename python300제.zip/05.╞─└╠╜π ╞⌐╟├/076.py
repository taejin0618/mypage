t = ('a', 'b', 'c')

t = ('A', 'b', 'c')
print(t)