inventory = {"메로나": [300, 20],
             "비비빅": [400, 3],
             "죠스바": [250, 100]}
inventory["월드콘"] = [500, 7]
print(inventory)