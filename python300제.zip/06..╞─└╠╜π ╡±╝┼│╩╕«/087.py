icecream = {"메로나": 1000, "폴라포": 1200, "빵파레": 1800}
icecream["죠스바"] = 1200
icecream["월드콘"] = 1500
print("메로나 가격: ", icecream["메로나"])