string = "삼성전자/LG전자/Naver"
interest = string.split("/")
print(interest)
