data = [2, 4, 3, 1, 5, 10, 9]
data.sort()
print(data)
