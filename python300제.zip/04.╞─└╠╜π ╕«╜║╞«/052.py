movie_rank = ["닥터 스트레인지", "스플릿", "럭키"]
movie_rank.append("배트맨")

print(movie_rank)