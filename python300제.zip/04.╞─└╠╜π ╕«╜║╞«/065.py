interest = ['삼성전자', 'LG전자', 'Naver']

print(interest[0],interest[2])
