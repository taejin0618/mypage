movie_rank = ["닥터 스트레인지", "스플릿", "럭키"]
movie_rank.append("배트맨")    # 리스트에 슈퍼맨 추가
movie_rank.insert(1,"슈퍼맨")  #   닥터 스트레인지, 스플릿 사이에 슈퍼맨 추가 insert

print(movie_rank)