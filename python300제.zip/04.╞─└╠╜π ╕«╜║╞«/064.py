nums = [1, 2, 3, 4, 5]
print(nums[::-1])   # 리스트 역방향 출력