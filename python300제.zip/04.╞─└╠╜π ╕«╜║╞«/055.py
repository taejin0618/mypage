movie_rank = ["닥터 스트레인지", "스플릿", "럭키"]
movie_rank.append("배트맨")    # 리스트에 슈퍼맨 추가
movie_rank.insert(1,"슈퍼맨")  #   닥터 스트레인지, 스플릿 사이에 슈퍼맨 추가 insert
del movie_rank[3]   # 인덱스 삭제 후 다시 계산하여 삭제
del movie_rank[3]   # 위에서 삭제 후 인덱스 다시 계산하여 3 위치에 있는 인덱스 삭제



print(movie_rank)