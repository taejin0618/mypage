num = 100
num_str = str(num)
print(num_str, type(num_str))