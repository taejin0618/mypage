text = "15.79"
sosu = float(text)
print(sosu, type(sosu))