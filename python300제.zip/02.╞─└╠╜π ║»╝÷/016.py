num_str = "720"  #형변환
num_int = int(num_str)
print(num_int)
print(type(num_int))