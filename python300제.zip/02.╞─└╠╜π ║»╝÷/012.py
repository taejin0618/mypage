시가총액 = 29800000000
현재가 = 50,000
PER = 15.79
print(시가총액, type(시가총액))
print(현재가, type(현재가))
print(PER, type(PER))
