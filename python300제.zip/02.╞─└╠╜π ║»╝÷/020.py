month = 48584
year = 36
print("총금액:", month * year)
